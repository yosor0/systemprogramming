#define MAXLINE 100
char *mygets (char *buf, size_t size);
void copy(char from[], char to[]);


