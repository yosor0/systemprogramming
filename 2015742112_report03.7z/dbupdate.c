#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"

int dbupdate(char *data) 
{
	int fd, id;
	char c;
	struct student rec;

	if ((fd = open(data, O_RDWR)) == -1) {
		perror(data);
		exit(1);
	}

	do {
		printf("수정할 학생의 학번 입력 : ");
		if (scanf("%d", &id) == 1) {
			lseek(fd, (long) (id - START_ID) * sizeof(rec), SEEK_SET);
			if ((read(fd, &rec, sizeof(rec)) > 0) && (rec.id != 0)) {
					printf("학번:%8d\t 이름%4s\t 점수:%d\n",
							rec.id, rec.name, rec.score);
					printf("새로운 점수 : ");
					scanf("%d", &rec.score);
					lseek(fd, (long) -sizeof(rec), SEEK_CUR);
					write(fd, &rec, sizeof(rec));
					}
					else printf("레코드 %d 없음\n", id);
		}
		else printf("입력오류\n");
		
		printf("계속하시겠습니까?(Y/N)");
		scanf(" %c", &c);
	} while (c == 'Y' || c == 'y');

	close(fd);
	exit(0);

}
