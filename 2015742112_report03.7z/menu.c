#include <stdio.h>
#include <stdlib.h>

int menu() {

	int select = 0;

	printf("학생 정보 데이터베이스\n");
	printf("1. 학생 정보 입력\n");
	printf("2. 학생 정보 검색\n");
	printf("3. 학생 정보 수정\n");
	printf("0. 프로그램 종료\n");
	printf("메뉴 입력 : ");

	scanf("%d", &select);

	return select;
}
