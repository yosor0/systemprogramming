#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"

int dbcreate (char *data)
{
	int fd;
	struct student rec;

	if ((fd = open(data, O_WRONLY | O_CREAT, 0640)) == -1) {
		perror(data);
		exit(1);
	}

	printf("%-9s %-8s %-4s\n", "학번", "이름", "점수");
	while(scanf("%d %s %d", &rec.id, rec.name, &rec.score) == 3) {
		lseek (fd, (rec.id - START_ID) * sizeof(rec), SEEK_SET);
		write(fd, &rec, sizeof(rec));
	}

	close(fd);
	exit(0);
}
