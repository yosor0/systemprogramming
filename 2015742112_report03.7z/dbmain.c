#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"

int menu();
int dbcreate(char *);
int dbquery(char *);
int dbupdate(char *);

int main(int argc, char *argv[]) {
	
	int c = 0;
	
	if (argc < 2) {
		fprintf(stderr, "사용법 : %s file\n", argv[0]);
		exit(1);
	}
	 
	while ((c = menu()) != 0) {
		switch (c) {
			case 1 : dbcreate(argv[1]);
					 break;
			case 2 : dbquery(argv[1]);
					 break;
			case 3 : dbupdate(argv[1]);
					 break;
			default : printf("\n잘못된 입력입니다.\n");
					  printf("다시 입력해 주세요\n\n");
			}
	}
	return 0;
}
