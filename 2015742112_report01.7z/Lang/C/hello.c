#include <stdio.h>
int main()
{
	printf("hello C world!\n");
	
	return 0;
}
