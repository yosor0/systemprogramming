<?
echo "Hello PHP world!";
?>
